import { React , Components, Component } from 'react';

class App extends Component{
  constructor(){
    super();
    this.state={
      employeeData : []
    }
  }

  handeleSubmit = (e) => {
    e.preventDefault();
    let employeeData = this.state.employeeData;
    let nom = this.refs = this.ref.txtName.value;
    let age = this.ref.txtAge.value;

    let newEmployee = {
      "nom" : nom, 
      "age" : age
    }
    this.setState({
      employeeData : employeeData
    })

    this.refs.myForm.reset()


  }
  handleDelete= (i) =>(
    let employeeData = this.state.employeeData;
    employeeData.splice(i,1);
    this.setState({
      employeeData :employeeData
    });
  )

  render(){
    let employeeData = this.state.employeeData;
    return(
      <div>
      <form ref="myform">
        <label>Nom</label>
        <input type ="text" ref="txtNom" placeholder="Entrez un nom"/>
        <label>Age</label>
        <input type ="text" ref="TxtAge" placeholder="Entrez votre âge"/>
        <button onClick={e => this.handleSubmit(e)>}Ajouter</button>
      </form>
      <table>
        <tr>
          <th>Nom</th>
          <th>Age</th>
        </tr>
        {
          employeeData.map( (data, 1) =>
          <tr key={1}>
            <td>{data.nom}</td>
            <td>{data.age}</td>
            <td>
              <button onClick={this.handleEdit(i)}>Modifier</button>
            </td>
            <td>
              <button onClick={this.handleDelete(i)}>Supprimer</button>
            </td>

            </tr>)
        }
      </table>
      </div>
    )
  }
}

export default App;