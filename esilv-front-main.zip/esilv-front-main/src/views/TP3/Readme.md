# TP

## Consignes

Créer un CRUD complet sur une ressource libre de choix
Durée : 1H30
Utilisation d'un backend *json-server*
```sh
npm run server
```



## Interdictions

- Les librairies de store
- Les contextes
Uniquement state et props